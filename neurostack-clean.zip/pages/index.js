import { useState } from 'react';
import Head from 'next/head';

export default function Home() {
  const [notes, setNotes]       = useState('');
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');
  const [result, setResult]     = useState(null);
  const [tab, setTab]           = useState('summary');
  const [cardIndex, setCardIndex] = useState(0);
  const [flipped, setFlipped]   = useState(false);
  const [mastered, setMastered] = useState([]);

  const words = notes.trim() ? notes.trim().split(/\s+/).length : 0;

  async function generate() {
    setError(''); setResult(null); setLoading(true);
    setCardIndex(0); setFlipped(false); setMastered([]);
    try {
      const res  = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Something went wrong.'); return; }
      setResult(data);
      setTab('summary');
    } catch { setError('Network error. Please try again.'); }
    finally   { setLoading(false); }
  }

  function next() {
    setFlipped(false);
    setTimeout(() => setCardIndex(i => Math.min(i + 1, result.flashcards.length - 1)), 120);
  }
  function prev() {
    setFlipped(false);
    setTimeout(() => setCardIndex(i => Math.max(i - 1, 0)), 120);
  }
  function gotIt() {
    setMastered(m => [...new Set([...m, cardIndex])]);
    if (cardIndex < result.flashcards.length - 1) next();
  }
  function reset() { setResult(null); setNotes(''); setMastered([]); setCardIndex(0); setFlipped(false); }

  const card = result?.flashcards[cardIndex];
  const pct  = result ? Math.round((mastered.length / result.flashcards.length) * 100) : 0;

  return (
    <>
      <Head>
        <title>NeuroStack — Notes to Flashcards</title>
        <meta name="description" content="Paste your notes. Get smart flashcards and a summary instantly." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div style={s.page}>

        {/* ── HEADER ── */}
        <header style={s.header}>
          <div style={s.logo}>Neuro<span style={s.accent}>Stack</span></div>
          <span style={s.badge}>✦ Powered by Gemini AI</span>
        </header>

        <main style={s.main}>

          {/* ── HERO ── */}
          {!result && (
            <div style={s.hero} className="fade-up">
              <h1 style={s.heroTitle}>
                Turn your notes into<br />
                <span style={s.accent}>flashcards & summaries</span>
              </h1>
              <p style={s.heroSub}>
                Paste any notes below — lectures, textbooks, study guides.<br />
                AI builds your study set in seconds. Free, no sign-up needed.
              </p>
            </div>
          )}

          {/* ── INPUT ── */}
          <div style={s.card}>
            <div style={s.cardHeader}>
              <span style={s.label}>Your notes</span>
              {result && <button style={s.resetBtn} onClick={reset}>← Start over</button>}
            </div>
            <textarea
              style={s.textarea}
              placeholder="Paste your lecture notes, textbook chapters, or study material here..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={7}
            />
            <div style={s.below}>
              <span style={s.wordCount}>{words} words</span>
              <button
                style={words < 10 || loading ? s.btnOff : s.btn}
                disabled={words < 10 || loading}
                onClick={generate}
              >
                {loading
                  ? <><span className="spinner"/>Generating...</>
                  : '✦ Generate flashcards & summary'}
              </button>
            </div>
          </div>

          {/* ── ERROR ── */}
          {error && <div style={s.error} className="fade-up">⚠ {error}</div>}

          {/* ── RESULTS ── */}
          {result && (
            <div className="fade-up">

              {/* Tabs */}
              <div style={s.tabs}>
                <button style={tab === 'summary' ? s.tabOn : s.tabOff} onClick={() => setTab('summary')}>
                  📋 Summary
                </button>
                <button style={tab === 'cards' ? s.tabOn : s.tabOff} onClick={() => { setTab('cards'); setFlipped(false); }}>
                  🃏 Flashcards ({result.flashcards.length})
                </button>
              </div>

              {/* ── SUMMARY TAB ── */}
              {tab === 'summary' && (
                <div style={s.card} className="fade-up">
                  <p style={s.sectionTitle}>📋 Key concepts</p>
                  {result.summary.map((pt, i) => (
                    <div key={i} style={s.bullet}>
                      <div style={s.dot}/>
                      <span style={s.bulletText}>{pt}</span>
                    </div>
                  ))}
                  <button style={{ ...s.btn, marginTop: '20px' }} onClick={() => { setTab('cards'); setCardIndex(0); setFlipped(false); }}>
                    Study flashcards →
                  </button>
                </div>
              )}

              {/* ── FLASHCARDS TAB ── */}
              {tab === 'cards' && card && (
                <div className="fade-up">

                  {/* Progress */}
                  <div style={s.progressRow}>
                    <span style={s.progressLabel}>
                      Card {cardIndex + 1} / {result.flashcards.length}
                      {mastered.includes(cardIndex) && <span style={s.masteredBadge}>✓ Mastered</span>}
                    </span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: 'var(--lime)' }}>
                      {mastered.length}/{result.flashcards.length} mastered
                    </span>
                  </div>
                  <div style={s.pbWrap}>
                    <div style={{ ...s.pbFill, width: `${pct}%` }}/>
                  </div>

                  {/* Flip card */}
                  <div style={s.fcWrap} onClick={() => setFlipped(f => !f)}>
                    <div style={flipped ? s.fcInnerFlipped : s.fcInner}>
                      {/* Front */}
                      <div style={s.fcFront}>
                        <span style={s.fcLabel}>Question</span>
                        <p style={s.fcQ}>{card.question}</p>
                        <span style={s.fcTap}>Tap to reveal answer</span>
                      </div>
                      {/* Back */}
                      <div style={s.fcBack}>
                        <span style={s.fcLabelGreen}>Answer</span>
                        <p style={s.fcA}>{card.answer}</p>
                        {card.hint && <p style={s.fcHint}>💡 {card.hint}</p>}
                      </div>
                    </div>
                  </div>

                  {/* Buttons */}
                  <div style={s.navRow}>
                    <button style={cardIndex === 0 ? s.navOff : s.nav} onClick={prev} disabled={cardIndex === 0}>← Prev</button>
                    <button style={s.gotIt} onClick={gotIt}>✓ Got it</button>
                    <button style={cardIndex === result.flashcards.length - 1 ? s.navOff : s.nav} onClick={next} disabled={cardIndex === result.flashcards.length - 1}>Next →</button>
                  </div>

                  {/* All done */}
                  {mastered.length === result.flashcards.length && (
                    <div style={s.doneBox} className="fade-up">
                      <span>🎉 You mastered all {result.flashcards.length} cards!</span>
                      <button style={s.retryBtn} onClick={() => { setMastered([]); setCardIndex(0); setFlipped(false); }}>
                        Study again
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </main>

        <footer style={s.footer}>NeuroStack · Free · No sign-up required</footer>
      </div>
    </>
  );
}

const s = {
  page:    { minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--bg)' },
  header:  { padding: '18px 28px', borderBottom: '1px solid var(--bd)', background: 'var(--bg2)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 10 },
  logo:    { fontSize: '22px', fontWeight: '800', letterSpacing: '-0.5px', color: 'var(--t1)' },
  accent:  { color: 'var(--lime)' },
  badge:   { fontSize: '12px', fontWeight: '600', background: 'var(--lime-dim)', border: '1px solid var(--lime-border)', color: 'var(--lime)', padding: '5px 14px', borderRadius: '20px' },
  main:    { flex: 1, maxWidth: '720px', width: '100%', margin: '0 auto', padding: '36px 20px' },

  hero:      { textAlign: 'center', marginBottom: '36px' },
  heroTitle: { fontSize: 'clamp(24px, 5vw, 40px)', fontWeight: '800', letterSpacing: '-1px', lineHeight: 1.2, marginBottom: '14px', color: 'var(--t1)' },
  heroSub:   { fontSize: '15px', color: 'var(--t2)', lineHeight: 1.7 },

  card:       { background: 'var(--bg2)', border: '1px solid var(--bd)', borderRadius: '20px', padding: '24px', marginBottom: '20px' },
  cardHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' },
  label:      { fontSize: '11px', fontWeight: '700', color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: '0.8px' },
  resetBtn:   { fontSize: '13px', fontWeight: '600', color: 'var(--t2)', background: 'none', border: 'none', cursor: 'pointer' },
  textarea:   { width: '100%', minHeight: '180px', background: 'var(--bg3)', border: '1px solid var(--bd)', borderRadius: '12px', padding: '14px', fontSize: '14px', color: 'var(--t1)', resize: 'vertical', fontFamily: 'inherit', lineHeight: '1.7' },
  below:      { marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '10px' },
  wordCount:  { fontSize: '12px', color: 'var(--t3)' },
  btn:        { width: '100%', padding: '15px', background: 'var(--lime)', color: '#0B0B14', border: 'none', borderRadius: '14px', fontSize: '15px', fontWeight: '700', cursor: 'pointer' },
  btnOff:     { width: '100%', padding: '15px', background: 'var(--bg3)', color: 'var(--t3)', border: '1px solid var(--bd)', borderRadius: '14px', fontSize: '15px', fontWeight: '700', cursor: 'not-allowed' },

  error: { background: 'rgba(255,107,107,0.1)', border: '1px solid rgba(255,107,107,0.3)', borderRadius: '12px', padding: '14px 16px', fontSize: '14px', color: '#FF6B6B', marginBottom: '20px' },

  tabs:   { display: 'flex', gap: '10px', marginBottom: '20px' },
  tabOn:  { flex: 1, padding: '12px', background: 'var(--lime-dim)', border: '1px solid var(--lime-border)', borderRadius: '12px', fontSize: '14px', fontWeight: '700', color: 'var(--lime)', cursor: 'pointer', textAlign: 'center' },
  tabOff: { flex: 1, padding: '12px', background: 'var(--bg2)', border: '1px solid var(--bd)', borderRadius: '12px', fontSize: '14px', fontWeight: '600', color: 'var(--t2)', cursor: 'pointer', textAlign: 'center' },

  sectionTitle: { fontSize: '17px', fontWeight: '700', color: 'var(--t1)', marginBottom: '18px' },
  bullet:       { display: 'flex', gap: '12px', alignItems: 'flex-start', marginBottom: '12px' },
  dot:          { width: '7px', height: '7px', borderRadius: '50%', background: 'var(--lime)', marginTop: '8px', flexShrink: 0 },
  bulletText:   { fontSize: '15px', color: 'var(--t1)', lineHeight: '1.6' },

  progressRow:   { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' },
  progressLabel: { fontSize: '13px', color: 'var(--t2)', fontWeight: '600' },
  masteredBadge: { marginLeft: '8px', fontSize: '11px', background: 'var(--lime-dim)', color: 'var(--lime)', border: '1px solid var(--lime-border)', padding: '2px 8px', borderRadius: '8px' },
  pbWrap:        { background: 'var(--bg3)', borderRadius: '4px', height: '5px', overflow: 'hidden', marginBottom: '20px' },
  pbFill:        { height: '100%', background: 'var(--lime)', borderRadius: '4px', transition: 'width 0.4s' },

  fcWrap:        { perspective: '1200px', height: '230px', cursor: 'pointer', marginBottom: '16px' },
  fcInner:       { position: 'relative', width: '100%', height: '100%', transformStyle: 'preserve-3d', transition: 'transform 0.5s cubic-bezier(0.4,0,0.2,1)' },
  fcInnerFlipped:{ position: 'relative', width: '100%', height: '100%', transformStyle: 'preserve-3d', transition: 'transform 0.5s cubic-bezier(0.4,0,0.2,1)', transform: 'rotateY(180deg)' },
  fcFront:       { position: 'absolute', width: '100%', height: '100%', backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden', background: 'var(--bg2)', border: '1px solid var(--bd)', borderRadius: '20px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '28px', textAlign: 'center' },
  fcBack:        { position: 'absolute', width: '100%', height: '100%', backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden', background: '#13132A', border: '1px solid rgba(170,255,69,0.2)', borderRadius: '20px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '28px', textAlign: 'center', transform: 'rotateY(180deg)' },
  fcLabel:       { fontSize: '10px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--t3)', marginBottom: '14px' },
  fcLabelGreen:  { fontSize: '10px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--lime)', marginBottom: '14px', opacity: 0.8 },
  fcQ:           { fontSize: '18px', fontWeight: '700', color: 'var(--t1)', lineHeight: '1.4', marginBottom: '8px' },
  fcA:           { fontSize: '15px', color: 'var(--t1)', lineHeight: '1.55', marginBottom: '10px' },
  fcHint:        { fontSize: '13px', color: 'var(--t2)', fontStyle: 'italic' },
  fcTap:         { fontSize: '12px', color: 'var(--t3)', marginTop: '6px' },

  navRow: { display: 'flex', gap: '10px', marginBottom: '14px' },
  nav:    { flex: 1, padding: '13px', background: 'var(--bg2)', border: '1px solid var(--bd)', borderRadius: '12px', fontSize: '14px', fontWeight: '600', color: 'var(--t1)', cursor: 'pointer' },
  navOff: { flex: 1, padding: '13px', background: 'var(--bg3)', border: '1px solid var(--bd)', borderRadius: '12px', fontSize: '14px', fontWeight: '600', color: 'var(--t3)', cursor: 'not-allowed' },
  gotIt:  { flex: 2, padding: '13px', background: 'var(--lime)', color: '#0B0B14', border: 'none', borderRadius: '12px', fontSize: '14px', fontWeight: '700', cursor: 'pointer' },

  doneBox:  { background: 'var(--lime-dim)', border: '1px solid var(--lime-border)', borderRadius: '16px', padding: '20px', textAlign: 'center', fontSize: '15px', fontWeight: '600', color: 'var(--lime)', display: 'flex', flexDirection: 'column', gap: '12px', alignItems: 'center' },
  retryBtn: { padding: '10px 24px', background: 'var(--lime)', color: '#0B0B14', border: 'none', borderRadius: '10px', fontSize: '14px', fontWeight: '700', cursor: 'pointer' },

  footer: { textAlign: 'center', padding: '20px', fontSize: '12px', color: 'var(--t3)', borderTop: '1px solid var(--bd)' },
};
