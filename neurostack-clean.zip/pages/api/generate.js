export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { notes } = req.body;
  if (!notes || notes.trim().length < 20) {
    return res.status(400).json({ error: 'Please paste more text (at least 20 characters).' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY is not set in your Vercel environment variables.' });
  }

  const prompt = `You are an expert study assistant. Given the notes below, produce two things:

1. SUMMARY: A clean bullet-point summary of the key concepts. Max 10 bullets. Each bullet = one clear sentence.

2. FLASHCARDS: 8-12 flashcards that test real understanding. Each card needs:
   - "question": something that makes the student think
   - "answer": clear and concise (1-3 sentences)
   - "hint": a simple analogy or memory trick (one sentence)

Reply ONLY with valid JSON — no extra text, no markdown fences:
{
  "summary": ["point 1", "point 2"],
  "flashcards": [
    { "question": "...", "answer": "...", "hint": "..." }
  ]
}

NOTES:
${notes.slice(0, 8000)}`;

  try {
    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.4, maxOutputTokens: 2048 }
        })
      }
    );

    if (!r.ok) return res.status(500).json({ error: 'Gemini API error. Check your API key.' });

    const data = await r.json();
    const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const clean = raw.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    if (!parsed.summary || !parsed.flashcards) {
      return res.status(500).json({ error: 'Unexpected response from AI. Try again.' });
    }

    return res.status(200).json(parsed);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
}
